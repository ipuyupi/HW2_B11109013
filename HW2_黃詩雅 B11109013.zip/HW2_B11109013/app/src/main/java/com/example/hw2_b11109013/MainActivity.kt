package com.example.hw2_b11109013

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.hw2_b11109013.ui.theme.HW2_黃詩雅B11109013Theme
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HW2_黃詩雅B11109013Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    AppNavHost(navController)
                }
            }
        }
    }
}

@Composable
fun AppNavHost(navController: NavController) {
    NavHost(navController = navController as NavHostController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            AttractionList(navController)
        }
        composable(Screen.Detail.route) { backStackEntry ->
            val attractionId = backStackEntry.arguments?.getString("attractionId")?.toInt()
            if (attractionId != null) {
                DetailScreen(navController, attractionId)
            }
        }
    }
}

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Detail : Screen("detail/{attractionId}") {
        fun createRoute(attractionId: Int) = "detail/$attractionId"
    }
}

data class Attraction(
    val id: Int,
    val nameResourceId: Int,
    val descriptionShortResourceId: Int,
    val descriptionLongResourceId: Int,
    val imageResourceId: Int,
    val locationUrl: String
)

class Datasource {
    fun loadAttractions(): List<Attraction> {
        return listOf(
            Attraction(
                1,
                R.string.great_wall_name,
                R.string.great_wall_short_description,
                R.string.great_wall_long_description,
                imageResourceId = R.drawable.greatwall,
                "geo:40.4319,116.5704"
            ),
            Attraction(
                2,
                R.string.ancient_city_name,
                R.string.ancient_city_short_description,
                R.string.ancient_city_long_description,
                imageResourceId = R.drawable.petra,
                "geo:30.3285,35.4444"
            ),
            Attraction(
                3,
                R.string.the_colosseum_name,
                R.string.the_colosseum_short_description,
                R.string.the_colosseum_long_description,
                imageResourceId = R.drawable.colloseum,
                "geo:41.8902,12.4922"
            ),
            Attraction(
                4,
                R.string.chichen_itza_name,
                R.string.chichen_itza_short_description,
                R.string.chichen_itza_long_description,
                imageResourceId = R.drawable.itza,
                "geo:20.6843,-88.5678"
            ),
            Attraction(
                5,
                R.string.machu_picchu_name,
                R.string.machu_picchu_short_description,
                R.string.machu_picchu_long_description,
                imageResourceId = R.drawable.machu,
                "geo:-13.1631,-72.5450"
            ),
            Attraction(
                6,
                R.string.taj_mahal_name,
                R.string.taj_mahal_short_description,
                R.string.taj_mahal_long_description,
                imageResourceId =  R.drawable.tajmahal,
                "geo:27.1751,78.0421"
            ),
            Attraction(
                7,
                R.string.christ_the_redeemer_name,
                R.string.christ_the_redeemer_short_description,
                R.string.christ_the_redeemer_long_description,
                imageResourceId = R.drawable.jesus,
                "geo:-22.9519,-43.2105"
            ),
        )
    }
}


@Composable
fun AttractionList(navController: NavController) {
    val attractions = Datasource().loadAttractions()

    val state = rememberLazyListState()
    val showScrollToTopButton by remember {
        derivedStateOf {
            state.firstVisibleItemIndex > 0
        }
    }

    LazyColumn(
        state = state,
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 8.dp,
            bottom = 8.dp
        ),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(attractions) { attraction ->
            AttractionItem(attraction) {
                navController.navigate(Screen.Detail.createRoute(it.id))
            }
        }
    }
}

@Composable
fun AttractionItem(attraction: Attraction, onClick: (Attraction) -> Unit) {
    val context = LocalContext.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick(attraction) }
            .padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column {
            Image(
                painter = painterResource(attraction.imageResourceId),
                contentDescription = stringResource(attraction.nameResourceId),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(194.dp),
                contentScale = ContentScale.Crop
            )
            Text(
                text = stringResource(attraction.nameResourceId),
                modifier = Modifier.padding(8.dp),
                style = MaterialTheme.typography.headlineSmall
            )
            Text(
                text = stringResource(attraction.descriptionShortResourceId),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(navController: NavController, attractionId: Int) {
    val context = LocalContext.current
    val attraction = getAttractionById(attractionId)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Attraction Details") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp)
        ) {
            Image(
                painter = painterResource(attraction.imageResourceId),
                contentDescription = stringResource(attraction.nameResourceId),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            )
            Spacer(modifier = Modifier.height(30.dp))
            Text(
                text = stringResource(attraction.nameResourceId),
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = MaterialTheme.typography.headlineSmall
            )
            Spacer(modifier = Modifier.height(30.dp))
            Text(
                text = stringResource(attraction.descriptionShortResourceId),
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(30.dp))
            Text(
                text = stringResource(attraction.descriptionLongResourceId),
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(30.dp))
            Button(onClick = {
                val gmmIntentUri = Uri.parse(attraction.locationUrl)
                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                mapIntent.setPackage("com.google.android.apps.maps")
                ContextCompat.startActivity(context, mapIntent, null)
            },
                modifier = Modifier.align(Alignment.CenterHorizontally),
                ) {
                Text(text = "View on Map")
            }
        }
    }
}

fun getAttractionById(id: Int): Attraction {
    val attractions = Datasource().loadAttractions()
    return attractions.first { it.id == id }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    HW2_黃詩雅B11109013Theme {
        AttractionList(navController = rememberNavController())
    }
}
